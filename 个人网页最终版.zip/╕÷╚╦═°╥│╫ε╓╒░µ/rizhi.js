$(document).ready(function(){
    $(".huiyuan-box01 .tab").click(function(){
      // 移除所有选项的背景色
      $(".huiyuan-box01 .tab").css("background-color", "");
      
      // 设置当前选项的背景色为灰色
      $(this).css("background-color", "#d9d9d9");
      
      // 显示对应的内容
      var tab = $(this).data("tab");
      $(".content").hide();
      $("#" + tab).show();
    });
    $(".huiyuan-box01 .tab").hover(function(){
      $(this).css("cursor", "pointer");
    }, function(){
      $(this).css("cursor", "default");
    });
    $(".huiyuan-box01 .tab").mousedown(function(){
      $(this).css("background-color", "#d9d9d9");
    });
    $(".huiyuan-box01 .tab").mouseup(function(){
      $(this).css("background-color", "");
    });
  });
  

