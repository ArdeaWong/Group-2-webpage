// index.js

function submitMessage() {
  const name = document.getElementById("name").value;
  const phone = document.getElementById("phone").value;
  const email = document.getElementById("email").value;
  const city = document.getElementById("city").value;
  const message = document.getElementById("message").value;

  // 发送POST请求给服务器
  fetch('http://localhost:3000/submitMessage', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      name: name,
      phone: phone,
      email: email,
      city: city,
      message: message,
    }),
  })
  .then(response => {
    if (!response.ok) {
      throw new Error('Network response was not ok');
    }
    return response.text();
  })
  .then(data => {
    // 显示提交成功消息
    document.getElementById("response-message").innerText = data;

    // 清空输入框
    document.getElementById("name").value = "";
    document.getElementById("phone").value = "";
    document.getElementById("email").value = "";
    document.getElementById("city").value = "";
    document.getElementById("message").value = "";
  })
  .catch(error => {
    console.error('Error:', error);
    // 显示错误消息
    document.getElementById("response-message").innerText = 'Error submitting message';
  });
}
