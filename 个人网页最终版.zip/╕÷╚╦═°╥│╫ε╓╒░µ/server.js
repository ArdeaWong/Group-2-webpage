const express = require('express');
const mysql = require('mysql');
const bodyParser = require('body-parser');
const path = require('path');  // 引入path模块

const app = express();
const port = 3000;

// MySQL数据库连接配置
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '123456',
  database: 'leaveword'
});

// 连接到MySQL数据库
db.connect(err => {
  if (err) {
    console.error('连接到 MySQL 时出错：' + err.stack);
    return;
  }
  console.log('已连接到 MySQL，线程 ID 为 ' + db.threadId);
});

// 解析POST请求体
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// 添加 'X-Content-Type-Options' 头部
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  next();
});

// 设置静态文件目录
app.use(express.static(__dirname));


// 处理留言提交
app.post('/submitMessage', (req, res) => {
  // ... 留言提交的处理逻辑
});

// 启动服务器
app.listen(port, () => {
  console.log(`服务器运行在 http://localhost:${port}`);
});
