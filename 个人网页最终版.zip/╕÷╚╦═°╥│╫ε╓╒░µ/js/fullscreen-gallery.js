document.addEventListener("DOMContentLoaded", function() {
    const images = ["images/16.jpg", "images/17.jpg","images/018.jpg"];
    let currentImageIndex = 0;

    const galleryContainer = document.createElement('div');
    galleryContainer.className = 'fullscreen-gallery';
    document.body.appendChild(galleryContainer);

    const galleryImage = document.createElement('img');
    galleryContainer.appendChild(galleryImage);

    const closeBtn = document.createElement('div');
    closeBtn.className = 'close-gallery';
    closeBtn.textContent = 'X';
    galleryContainer.appendChild(closeBtn);

    closeBtn.addEventListener('click', function() {
        galleryContainer.style.display = 'none';
    });

    document.querySelectorAll('.gallery-img').forEach(img => {
        img.addEventListener('dblclick', function() {
            openFullscreenGallery(images.indexOf(this.src));
        });
    });

    function openFullscreenGallery(index) {
    if (index < 0 || index >= images.length) {
        // 如果索引无效，则设置为第一张图片
        index = 0;
    }
    currentImageIndex = index;
    galleryImage.src = images[currentImageIndex];
    galleryContainer.style.display = 'block';
}


    const leftControl = document.createElement('div');
    leftControl.className = 'gallery-control left';
    leftControl.textContent = '<';
    galleryContainer.appendChild(leftControl);

    const rightControl = document.createElement('div');
    rightControl.className = 'gallery-control right';
    rightControl.textContent = '>';
    galleryContainer.appendChild(rightControl);

    leftControl.addEventListener('click', function() {
        if (currentImageIndex > 0) {
            currentImageIndex--;
            galleryImage.src = images[currentImageIndex];
        }
    });

    rightControl.addEventListener('click', function() {
        if (currentImageIndex < images.length - 1) {
            currentImageIndex++;
            galleryImage.src = images[currentImageIndex];
        }
    });
});

function showImage(src) {
    // 创建一个新的图片元素
    var img = document.createElement('img');
    img.src = src;
    img.style.maxWidth = '80%';
    img.style.maxHeight = '80%';
    img.style.position = 'absolute';
    img.style.top = '50%';
    img.style.left = '50%';
    img.style.transform = 'translate(-50%, -50%)';

    // 创建一个关闭按钮
    var closeButton = document.createElement('span');
    closeButton.innerHTML = '&times;';
    closeButton.style.position = 'absolute';
    closeButton.style.top = '10px';
    closeButton.style.right = '20px';
    closeButton.style.color = 'white';
    closeButton.style.fontSize = '30px';
    closeButton.style.cursor = 'pointer';
    closeButton.onclick = function() {
        document.body.removeChild(overlay);
    };

    // 创建一个覆盖层
    var overlay = document.createElement('div');
    overlay.style.position = 'fixed';
    overlay.style.top = '0';
    overlay.style.left = '0';
    overlay.style.width = '100%';
    overlay.style.height = '100%';
    overlay.style.backgroundColor = 'rgba(0, 0, 0, 0.8)';
    overlay.style.zIndex = '1000';

    // 将图片和关闭按钮添加到覆盖层
    overlay.appendChild(img);
    overlay.appendChild(closeButton);

    // 将覆盖层添加到页面中
    document.body.appendChild(overlay);
}
